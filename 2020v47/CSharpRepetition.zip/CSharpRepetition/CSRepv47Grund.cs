﻿namespace CSharpRepetition.Net20.MarcusMedina
{
    using System;

    /// <summary>
    /// Testa dina grundkunskaper i C#
    /// </summary>
    public class CSRepv47Grund
    {
        /// <summary>
        /// Du kommer att få ett obestämt antal tal som funktionen ska
        /// returnera medelvärde på
        /// (Linq Average räknas som fusk).
        /// </summary>
        /// <param name="tal">Alla tal som ska behandlas</param>
        /// <returns>Medelvärdet av talen</returns>
        public int Medelvärde(params int[] tal)
        {
            int summa = 0;
            // ---------------------------------------------------------------------------------
            // Skriv din kod nedan
            // ---------------------------------------------------------------------------------

            // ---------------------------------------------------------------------------------
            int res = summa / tal.Length;
            Console.WriteLine("  Medelvärdet är : " + res);
            return res;
        }

        /// <summary>
        /// Du kommer att få ett obestämt antal tal som funktionen ska
        /// returnera lägsta och högsta värdet av de talen
        /// (Linq Max/Min räknas som fusk).
        /// </summary>
        /// <param name="tal">Talen som ska kontrolleras</param>
        /// <returns>Max och Minimivärden.</returns>
        public (int, int) MinimiOchMaximiVärde(params int[] tal)
        {
            var max = int.MinValue;
            var min = int.MaxValue;
            // ---------------------------------------------------------------------------------
            // Skriv din kod nedan
            // ---------------------------------------------------------------------------------

            // ---------------------------------------------------------------------------------
            Console.WriteLine("  Min och Max    : " + (min, max));
            return (min, max);
        }

        /// <summary>
        /// Skapa en loop som går igenom alla siffror i en sträng
        /// och adderar dem, när den är klar ska den returnera
        /// summan, exempelvis "552" ska ge svaret "12" alla andra
        /// tecken ska ignoreras "54.3" ska bli 12.
        /// </summary>
        /// <param name="nummer">Sträng med nummeriska värden<see cref="string"/>.</param>
        /// <returns>Summan av alla tal i strängen.</returns>
        public int SummeraText(string nummer)
        {
            int summa = 0;
            // ---------------------------------------------------------------------------------
            // Skriv din kod nedan
            // ---------------------------------------------------------------------------------

            // ---------------------------------------------------------------------------------
            Console.WriteLine("  Summa          : " + summa);
            return summa;
        }
    }
}