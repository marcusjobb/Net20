﻿namespace CSharpRepetition.Net20.MarcusMedina
{
    using System;

    /// <summary>
    /// Testa dina avancerade kunskaper i C#
    /// </summary>
    public class CSRep47Avancerad
    {
        /// <summary>
        /// The AntalDagar.
        /// </summary>
        /// <param name="start">Startdatum<see cref="DateTime"/>.</param>
        /// <param name="slut">Slutdatum<see cref="DateTime"/>.</param>
        /// <returns>Antal dagar - <see cref="int"/>.</returns>
        public int AntalDagar(DateTime start, DateTime slut)
        {
            var resultat = 0;
            // ---------------------------------------------------------------------------------
            // Skriv din kod nedan
            // ---------------------------------------------------------------------------------

            // ---------------------------------------------------------------------------------
            Console.WriteLine($"  Antal dagar    : {resultat}");
            return resultat;
        }

        /// <summary>
        /// Den här metoden lägger till x antal månader till det datumet som skickats in
        /// </summary>
        /// <returns>Det nya datumet</returns>
        public DateTime LäggTillMånad(DateTime date, int month)
        {
            DateTime resultat = DateTime.Now;
            // ---------------------------------------------------------------------------------
            // Skriv din kod nedan
            // ---------------------------------------------------------------------------------

            // ---------------------------------------------------------------------------------
            Console.WriteLine($"  Datum         : {resultat}");
            return resultat;
        }

        /// <summary>
        /// Den här metoden ska ta trå strängar och addera dem
        /// varannan bokstav,
        /// Exempel: Katt,Hund = KHautntd.
        /// </summary>
        /// <param name="first">Första ordet<see cref="string"/>.</param>
        /// <param name="second">Andra ordet<see cref="string"/>.</param>
        /// <returns>Ny sträng med bokstäverna blandade</returns>
        public string VarannanBokstav(string first, string second)
        {
            string resultat = "";
            // ---------------------------------------------------------------------------------
            // Skriv din kod nedan
            // ---------------------------------------------------------------------------------

            // ---------------------------------------------------------------------------------
            Console.WriteLine($"  Bokstäver      : {resultat}");
            return resultat;
        }
    }
}