﻿namespace CSharpRepetition.Net20.MarcusMedina
{
    using System;

    /// <summary>
    /// Testa dina kodninjakunskaper
    /// </summary>
    public class CSRepv47Ninja
    {
        /// <summary>
        /// Den här metoden krypterar en textsträng enligt Caesarchiffer,
        /// enbart åäö, bokstäver, siffror, punkt, komma och mellanslag är godkända
        /// för input, övrigt ska ignoreras
        /// Nyckeln talar om hur många positioner en bokstav eller ett nummer ska flyttas
        /// nyckel:3 --> a=c, b=d, c=e
        /// </summary>
        /// <param name="code">Text som ska krypteras</param>
        /// <param name="key">Nyckel som ska användas till kryptering</param>
        /// <returns>Krypterad sträng</returns>
        public string Caesarchiffer(string code, int key)
        {
            string resultat = "";
            // ---------------------------------------------------------------------------------
            // Skriv din kod nedan
            // ---------------------------------------------------------------------------------

            // ---------------------------------------------------------------------------------
            Console.WriteLine(" Caesar       :" + resultat);
            return resultat;
        }

        /// <summary>
        /// Dechifrerar text
        /// </summary>
        /// <param name="code">Texten</param>
        /// <param name="key">Nyckel</param>
        /// <returns>Dechifrerad text</returns>
        public string Caesardechiffer(string code, int key)
        {
            string resultat = "";
            // ---------------------------------------------------------------------------------
            // Skriv din kod nedan
            // ---------------------------------------------------------------------------------

            // ---------------------------------------------------------------------------------
            return resultat;
        }
    }
}