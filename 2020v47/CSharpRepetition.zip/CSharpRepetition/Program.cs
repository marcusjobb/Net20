﻿namespace CSharpRepetition.Net20.MarcusMedina
{
    using System;
    using System.Text;

    /// <summary>
    /// För att få programmet att fungera kolla koden för classerna
    ///
    /// * <see cref="CSRepv47Grund"/>Grund
    /// * <see cref="CSRep47Avancerad"/>Avancerad
    /// * <see cref="CSRepv47Ninja"> Ninja
    ///
    /// Programmet försöker köra alla metoder i classerna,
    /// och kommer att visa dig procent av hur många metoder
    /// som fungerar som de ska
    ///
    /// Gott råd: Undvik Linq och StackOverflow, det kan lösa problemet
    /// men du lär dig inget av det. Tanken är att du själv ska lösa det
    ///.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// Main metoden
        /// </summary>
        private static void Main()
        {
            StringBuilder result = new System.Text.StringBuilder("\nResultat:");
            double g = Checka.Grund();
            double a = Checka.Avancerad();
            double n = Checka.Ninja();
            double s = (g + a + n) / 300;
            double t = Math.Round(s * 100, 1);

            result.AppendLine()
                .AppendLine(new string('-', 110))
                .Append(" Grund     : ").Append(g).AppendLine(" %")
                .Append(" Avancerad : ").Append(a).AppendLine(" %")
                .Append(" Ninja     : ").Append(n).AppendLine(" %")
                .AppendLine(new string('-', 110))
                .Append(" Total     : ").Append(t).AppendLine(" %")
                .AppendLine(new string('-', 110))
                ;

            Console.WriteLine(result.ToString());
        }
    }
}